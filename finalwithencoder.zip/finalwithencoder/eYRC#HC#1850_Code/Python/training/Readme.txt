Please put the dataset in this folder 
The .pth file will be saved in this folder itself