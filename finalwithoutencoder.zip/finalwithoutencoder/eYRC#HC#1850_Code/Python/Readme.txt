example format for running the programe 
python task4-main.py C:\Users\bharathambika\Desktop\Original\Original.png
could also specify model path with -amod and -hmod by default its the same folder
could save the output image using -s 