Please put the dataset and the model in this folder before running any 
of the accuracy programs